import pygame, fingers, levels
from physics import *
from animation import Timer
from player import Player
from button import Button
from camera import Camera
pygame.init()


class Game():
    def __init__(self):
        self.screen = pygame.display.set_mode((256, 240), pygame.SCALED | pygame.FULLSCREEN)
        self.clock = pygame.time.Clock()
        self.scene_manager = SceneManager()
        self.MAX_FPS = 30
    def run(self):
        run = True
        while run:
            events = pygame.event.get()
            for event in events:
                if event.type == pygame.QUIT:
                    run= False
                    pygame.quit()
                    quit()
                fingers.handle_event(event, (self.screen.get_width(), self.screen.get_height()))
            
            self.scene_manager.run(self.screen, events)
            
            pygame.display.update()
            self.clock.tick(self.MAX_FPS)

class SceneStart():
    def __init__(self):
        self.timers = [
            Timer(0.5),
            Timer(1),
            Timer(0.5)
        ]
        self.start_image = pygame.transform.scale_by(pygame.image.load('assets/images/ui/pics/start_logo.png').convert_alpha(), 2)
        self.start_image_rect = self.start_image.get_rect()
        self.reset()
        
    def reset(self):
        self.start_image_alpha = 0
        self.timers[0].reset()
        self.timers[1].reset()
        self.timers[2].reset()
        
        
    def run(self, screen, events, scene_manager):
        self.start_image_rect.center = screen.get_rect().center
        self.start_image.set_alpha(self.start_image_alpha)
        screen.fill((0, 0, 0))
        screen.blit(self.start_image, self.start_image_rect)
        if self.timers[0].istimer() and self.timers[1].TIMER == 0:
            self.start_image_alpha = min(255, self.start_image_alpha + 5)
            if self.start_image_alpha == 255:
                self.timers[1].istimer()
        elif self.timers[1].TIMER != 0:
            if self.timers[1].istimer() and self.timers[2].TIMER == 0:
                self.start_image_alpha = min(255, self.start_image_alpha - 5)
                if self.start_image_alpha == 0:
                    self.timers[2].istimer()
            elif self.timers[2].TIMER != 0:
                if self.timers[1].istimer() and self.timers[2].istimer():
                    scene_manager.set_scene('1')
        
        
class Scene1():
    def __init__(self):
        self.reset()
        
    def reset(self):
        self.camera = Camera((0, 0))
        self.player = Player()
        OBJECTS.clear()
        OBJECTS.add_object('player', [self.player])
        levels.load_levels()
        levels.set_level('1')
        levels.add_level_to_physics(OBJECTS)
        #self.blocks = pygame.sprite.Group()
#        self.blocks.add([BlockQuestion('overworld', ((8 + x) * 16, 168)) for x in range(1, 5)])
#        for block in self.blocks:
#            OBJECTS.add_object(block)
        
        # buttons
        self.control_buttons = []
        for name in ['a', 'b', 'left', 'right', 'up', 'down']:
            if name == 'a':
                pos = (216, 200)
            elif name == 'b':
                pos = (216, 72)
            elif name == 'left':
                pos = (8, 184)
            elif name == 'right':
                pos = (72, 184)
            elif name == 'up':
                pos = (40, 168)
            elif name == 'down':
                pos = (40, 200)
            imported_images = (pygame.image.load('assets/images/ui/game_control/'+name+'.png').convert_alpha(), pygame.image.load('assets/images/ui/game_control/'+name+'.png'))
            imported_images[0].set_alpha(120)
            imported_images[0].convert_alpha()
            imported_images[1].set_alpha(200)
            imported_images[1].convert_alpha()
            self.control_buttons.append(Button(pos, imported_images))
        self.buttons_group = pygame.sprite.Group(self.control_buttons)
    
    def run(self, screen, events, scene_manager):
        screen.fill((255, 255, 255))
        self.buttons_group.update(fingers.fingers)
        rect1 = self.player.sprite.rect
        rect2 = rect1
        rect1.center = self.player.hitrect.center
        self.camera.set_cam(rect1, rect2, (screen.get_width(), screen.get_height()))
        del rect1, rect2
        levels.level_update(OBJECTS)
        levels.level_draw(screen, self.camera.get_cam())
        levels.level_physics(OBJECTS)
        self.player.draw(screen, self.camera.get_cam())
        self.player.physics(OBJECTS, {'left': self.control_buttons[2].pressing, 'right': self.control_buttons[3].pressing, 'up': self.control_buttons[4].pressing, 'down': self.control_buttons[5].pressing, 'b': self.control_buttons[1].pressing, 'a': self.control_buttons[0].pressing}, screen, self.camera.get_cam())
        self.buttons_group.draw(screen)

class SceneManager():
    def __init__(self):
        self.scene = '-1'
        self.scenes = {
            '-1': SceneStart(),
            '1': Scene1()
        }
    def set_scene(self, scene):
        self.scene = scene
        self.scenes[self.scene].reset()
    def run(self, screen, events):
        self.scenes[self.scene].run(screen, events, self)

if __name__ == '__main__':
    Game().run()