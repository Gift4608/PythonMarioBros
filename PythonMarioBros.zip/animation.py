import pygame, time

class Animation():
    def __init__(self, path, num, speed):
        self.TIMER, self.SPEED, self.SPRITE = 0, speed, 0
        sprites = []
        for image_id in range(1, num+1):
            sprites.append(pygame.image.load(path + str(image_id) + '.png').convert_alpha())
        self.SPRITES = tuple(sprites)
    def reset(self):
        self.TIMER, self.SPRITE = 0, 0
    def animation(self):
        if self.TIMER == 0:
            self.TIMER = time.time()
        if time.time() - self.TIMER >= self.SPEED:
            self.SPRITE = (self.SPRITE+1) % len(self.SPRITES)
            self.TIMER = 0
        return self.SPRITES[self.SPRITE]

class Timer():
    def __init__(self, speed):
        self.TIMER, self.SPEED = 0, speed
    def reset(self):
        self.TIMER = 0
    def istimer(self):
        if self.TIMER == 0:
            self.TIMER = time.time()
        if time.time() - self.TIMER >= self.SPEED:
            return True
        else:
            return False