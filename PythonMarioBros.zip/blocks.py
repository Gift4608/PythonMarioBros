import pygame
from animated_sprite import Animated_sprite
from physics import *
from animation import *

class Block(Physics):
    def __init__(self, theme, pos1, sprite):
        super().__init__(
            sprite, 
            dynamic=False,
            pos=pos1
        )
        self.theme = theme

class BlockHit(Block):
    def __init__(self, theme, pos1, sprite, empty=True):
        super().__init__(
            theme,
            pos1, 
            sprite, 
        )
        self.hited_timer = Timer(0.1)
        self.stay_timer = Timer(0.2)
        self.empty = empty
        self.oppened = False
        self.will_oppened = False
    def update(self, physical_objects):
        self.sprite.update_image()
        if not self.oppened:
            if self.stay_timer.istimer():
                for sprite in physical_objects.objects['normal'].sprites():
                    self.hitrect.y += 1
                    if self.hitrect.colliderect(sprite.hitrect) and sprite != self and sprite.dynamic:
                        if self.hitrect.bottom-1 == sprite.hitrect.top and not sprite.isonfloor(physical_objects) and sprite.isonceiling(physical_objects):
                             self.hited_timer.reset()
                             self.stay_timer.reset()
                             self.sprite.offrect.y -= 2
                             self.sprite.change_anim(1 if self.empty else 2)
                             self.hitrect.y += -1
                             self.will_oppened = True
                             break
                    self.hitrect.y -= 1
            if self.hited_timer.istimer():
                self.sprite.offrect.y = 0
                if self.empty:
                    self.sprite.change_anim(0)
                elif self.will_oppened:
                    self.oppened = True
                    self.sprite.change_anim(4)
                    del self.will_oppened, self.hited_timer, self.stay_timer

class BlockGround(Block):
    def __init__(self, theme, pos1):
        super().__init__(
            theme,
            pos1,
            Animated_sprite(
                tuple([Animation('assets/images/blocks/' + theme + '/ground/', 1, 0.05)])
            )
        )

class BlockBrick(BlockHit):
    def __init__(self, theme, pos1, empty=True):
        super().__init__(
            theme,
            pos1, 
            Animated_sprite(
                (Animation('assets/images/blocks/' + theme + '/brick/idle/', 1, 0), Animation('assets/images/blocks/' + theme + '/brick/hitted0/', 1, 0), Animation('assets/images/blocks/' + theme + '/brick/hitted1/', 1, 0), Animation('assets/images/blocks/' + theme + '/brick/break/', 1, 0), Animation('assets/images/blocks/' + theme + '/oppened/', 1, 0.05))
            ),
            empty
        )

class BlockQuestion(BlockHit):
    def __init__(self, theme, pos1):
        super().__init__(
            theme,
            pos1, 
            Animated_sprite(
                (Animation('assets/images/blocks/' + theme + '/question/idle/', 5, 0.1), Animation('assets/images/blocks/' + theme + '/question/idle/', 1, 0), Animation('assets/images/blocks/' + theme + '/question/hitted/', 1, 0.05), Animation('assets/images/blocks/' + theme + '/question/idle/', 1, 0), Animation('assets/images/blocks/' + theme + '/oppened/', 1, 0.05))
            ),
            False
        )

class BlockOppened(Block):
    def __init__(self, theme, pos1):
        super().__init__(
            theme,
            pos1,
            Animated_sprite(
                tuple([Animation('assets/images/blocks/' + theme + '/ground/', 1, 0.05)])
            )
        )