import pygame

class Camera():
    def __init__(self, pos, use_mp=True, min_point=(0, 0), go_x=True, go_y=True):
        self.use_mp, self.min_point, self.go_x, self.go_y = use_mp, min_point, go_x, go_y
        self.x, self.y = pos
    def get_cam(self):
        return (self.x, self.y)
    def set_cam(self, target_rect, target_offseted_rect, screen_res):
        if self.go_x:
            self.x = target_rect.x
            self.x -= screen_res[0] / 2
            if self.use_mp:
                self.x = max(self.x, self.min_point[0])
        if self.go_y:
            self.y = target_rect.y
            
            if self.use_mp:
                self.y = min(self.y, screen_res[1] / 2 - self.min_point[1])
            self.y -= screen_res[1] / 2