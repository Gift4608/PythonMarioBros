import pygame

fingers = {}

def handle_event(event, screen_res):
    global fingers
    if event.type in (pygame.FINGERDOWN, pygame.FINGERMOTION):
        fingers[event.finger_id] = (event.x * screen_res[0], event.y * screen_res[1])
    if event.type == pygame.FINGERUP:
        fingers.pop(event.finger_id, None)

def rect_collideany_finger(rect):
    global fingers
    touch = False
    for id, pos in fingers.items():
        if rect.collidepoint(pos):
            touch = True
    return touch