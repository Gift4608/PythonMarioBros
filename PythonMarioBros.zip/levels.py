import pygame
from assets import lvls

level = []
levels = {}
lvl_name = '1'

def load_levels():
    global levels
    levels = lvls.get()

def set_level(name):
    global lvl_name, level
    lvl_name = name
    level = levels[lvl_name]

def get_level():
    return level

def add_level_to_physics(physical_objects):
    global level
    level_norm = []
    level_trig = []
    for sprite in level:
        if sprite.trigger:
            level_trig.append(sprite)
        else:
            level_norm.append(sprite)
            
    physical_objects.objects['normal']['level'] = level_norm
    physical_objects.objects['triggers']['level'] = level_trig

def level_physics(physical_objects):
    for item in level:
        item.physics(physical_objects)

def level_update(physical_objects):
    for item in level:
        item.update(physical_objects)

def level_draw(screen, cam=(0, 0)):
    for item in level:
        item.draw(screen, cam)