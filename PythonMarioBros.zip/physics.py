import pygame

class PhysicalObjects():
    def __init__(self):
        self.clear()
    def add_object(self, object_name, object, trigger=False):
        if not trigger:
            self.objects['normal'][object_name] = object
        else:
            self.objects['triggers'][object_name] = object
    def clear(self):
        self.objects = {
            'normal': {}, 
            'triggers': {}
        }

OBJECTS = PhysicalObjects()

class Physics(pygame.sprite.Sprite):
    def __init__(self, sprite, hitrect=None, pos=(0, 0), dynamic=True, trigger=False, slippery=0.65, gravity=0.5, collide_walls=False):
        super().__init__()
        self.sprite = sprite
        if hitrect != None:
            self.hitrect = hitrect
            self.hitrect.center = self.sprite.rect.center
        else:
            self.hitrect = self.sprite.rect
        self.hitrect.topleft = pos
        self.sprite.rect.center = self.hitrect.center
        self.dynamic = dynamic
        self.trigger = trigger
        self.velocity = [0, 0]
        self.gravity = gravity
        self.slippery = slippery
        self.collide_walls = collide_walls
    def draw(self, screen, cam=(0, 0)):
        screen.blit(self.sprite.image, (self.sprite.rect.x + self.sprite.offrect.x - cam[0], self.sprite.rect.y + self.sprite.offrect.y - cam[1]))
    def isonfloor(self, physical_objects):
        collided = False
        if not self.trigger:
            if self.dynamic:
                self.hitrect.y += 1
                for name, group in physical_objects.objects['normal'].items():
                    for sprite in group:
                        if self.hitrect.colliderect(sprite.hitrect) and sprite != self:
                            collided = True
                self.hitrect.y -= 1
        return collided
    def isonceiling(self, physical_objects):
        collided = False
        if not self.trigger:
            if self.dynamic:
                self.hitrect.y -= 1
                for name, group in physical_objects.objects['normal'].items():
                    for sprite in group:
                        if self.hitrect.colliderect(sprite.hitrect) and sprite != self:
                            collided = True
                self.hitrect.y += 1
        return collided
    def physics(self, physical_objects, screen=None, cam=(0, 0)):
        if not self.trigger:
            if self.dynamic:
                collided = False
                # physics by x
                self.hitrect.x = round(self.hitrect.x + self.velocity[0])
                if self.collide_walls:
                    spriterect = self.sprite.rect
                    spriterect.centerx = self.hitrect.centerx
                    if cam[0] == 0:
                        if spriterect.left < 0:
                            spriterect.left = 0
                            collided = True
                            self.velocity[0] = 0
                            self.hitrect.centerx = spriterect.centerx
                        elif spriterect.right > screen.get_width():
                            spriterect.right = screen.get_width()
                            collided = True
                            self.velocity[0] = 0
                            self.hitrect.centerx = spriterect.centerx
                    del spriterect
                for name, group in physical_objects.objects['normal'].items():
                    for sprite in group:
                        if self.hitrect.colliderect(sprite.hitrect) and sprite != self:
                            collided = True
                            if self.velocity[0] > 0:
                                self.hitrect.right = sprite.hitrect.left
                            elif self.velocity[0] < 0:
                                self.hitrect.left = sprite.hitrect.right
                            self.velocity[0] = 0
                if not collided:
                    self.velocity[0] *= self.slippery
                collided = False
                # physics by y
                self.hitrect.y += self.velocity[1]
                for name, group in physical_objects.objects['normal'].items():
                    for sprite in group:
                        if self.hitrect.colliderect(sprite.hitrect) and sprite != self:
                            collided = True
                            if self.velocity[1] > 0:
                                self.hitrect.bottom = sprite.hitrect.top
                                self.velocity[1] = 0
                            elif self.velocity[1] < 0:
                                self.hitrect.top = sprite.hitrect.bottom
                                self.velocity[1] = 1
                if not collided:
                    self.velocity[1] += self.gravity
                    if self.velocity[1] == 0:
                        self.velocity[1] += self.gravity
                    self.velocity[1] = min(self.sprite.image.get_height(), self.velocity[1])
        self.sprite.rect.center = self.hitrect.center