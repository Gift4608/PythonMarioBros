from blocks import *

def get():
    levels = {
        '1': [BlockGround('overworld', (x*16, 216 + y*16)) for x in range(16) for y in range(2)]
    }
    return levels