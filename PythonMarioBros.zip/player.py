import pygame
from animated_sprite import Animated_sprite
from physics import *
from animation import Animation
from math import floor, ceil

class Player(Physics):
    def __init__(self):
        super().__init__(Animated_sprite(tuple([
            Animation('assets/images/mario/idle/', 1, 0.05), 
            Animation('assets/images/mario/walk/', 3, 0.05), 
            Animation('assets/images/mario/walk/', 3, 0.015), 
            Animation('assets/images/mario/dash/', 1, 0.05), 
            Animation('assets/images/mario/jump/', 1, 0.05), 
            Animation('assets/images/mario/swim/', 5, 0.05), 
            Animation('assets/images/mario/climb/', 2, 0.05), 
            Animation('assets/images/mario/die/', 1, 0.05), 
            Animation('assets/images/mario/down/', 1, 0.05)
        ])), gravity=0.5, slippery=0.85, hitrect = pygame.rect.Rect((0, 0), (12, 15)), pos=(24, 132), collide_walls=True)
        self.walk_speed = 2
        self.run_speed = 3.5
        self.max_jump_height = -54
        self.pixel_jump_counter = 0
        self.jump_counter = 0
        self.normal_gravity = 0.5
        self.water_gravity = 0.125
        self.gravity = self.normal_gravity
        self.dir = 0
        
    def draw(self, screen, cam):
        screen.blit(pygame.transform.flip(self.sprite.image, self.dir, False), (self.sprite.rect.x - cam[0], self.sprite.rect.y - cam[1]))
        #screen.blit(pygame.surface.Surface((16, 16)), self.sprite.rect)
    
    def physics(self, physical_objects, buttons, screen, cam=(0, 0)):
        if (buttons['left'] or buttons['right']) and (not buttons['left'] or not buttons['right']):
            if not buttons['b']:
                self.velocity[0] = (buttons['right'] - buttons['left']) * self.walk_speed
            else:
                self.velocity[0] = (buttons['right'] - buttons['left']) * self.run_speed
                
        if self.gravity == self.normal_gravity:
            if buttons['a']:
                if (self.pixel_jump_counter > self.max_jump_height) and (self.isonfloor(physical_objects) or self.pixel_jump_counter < 0 and self.velocity[1] < 0):
                    if self.isonfloor(physical_objects):
                        self.jump_counter += 1
                    if self.jump_counter == 1:
                        self.velocity[1] = -4.5
                        self.pixel_jump_counter -= 4.5
            else:
                if self.pixel_jump_counter < 0:
                    self.pixel_jump_counter = 0
                self.jump_counter = 0
            if self.pixel_jump_counter < 0 and self.isonceiling(physical_objects):
                self.pixel_jump_counter = 0
        elif self.gravity == self.water_gravity:
            if buttons['a']:
                self.jump_counter += 1
                if self.jump_counter == 1:
                    self.velocity[1] = -2.5595238095238086
                    self.pixel_jump_counter = 0
            else:
                self.jump_counter = 0
                
        super().physics(physical_objects, screen, cam)
        self.afterphysics(buttons, physical_objects)
    
    def afterphysics(self, buttons, physical_objects):
        swich_anim_image = True
        if round(self.velocity[0]) == 0 and self.isonfloor(physical_objects) and (buttons['right'], buttons['left']) == (False, False):
            if buttons['down']:
                if self.sprite.current_anim != 8:
                    self.sprite.change_anim(8)
            else:
                if self.sprite.current_anim != 0:
                    self.sprite.change_anim(0)
        else:
            if self.gravity == self.water_gravity and not self.isonfloor(physical_objects) and self.sprite.current_anim != 5:
                self.sprite.change_anim(5)
            else:
                if self.jump_counter > 0 and not self.isonfloor(physical_objects) and self.sprite.current_anim != 4 and self.gravity != self.water_gravity:
                    self.sprite.change_anim(4)
                else:
                    if (buttons['left'] or buttons['right']) and buttons['right'] - buttons['left'] != 0 and not buttons['b'] and self.isonfloor(physical_objects) and self.sprite.current_anim != 1 and (self.gravity != self.water_gravity or self.isonfloor(physical_objects)):
                            self.sprite.change_anim(1)
                    else:
                        if (buttons['left'] or buttons['right']) and buttons['right'] - buttons['left'] != 0 and buttons['b'] and self.isonfloor(physical_objects) and self.sprite.current_anim != 2 and (self.gravity != self.water_gravity or self.isonfloor(physical_objects)):
                            self.sprite.change_anim(2)
                        else:
                            if buttons['right'] - buttons['left'] == 0 and round(self.velocity[0]) != 0 and self.isonfloor(physical_objects) and (self.gravity != self.water_gravity or self.isonfloor(physical_objects)):
                                self.sprite.change_anim(3)
        if swich_anim_image:
            self.sprite.update_image()
        else:
            self.sprite.image = self.sprite.animations[self.sprite.current_anim].SPRITES[self.sprite.animations[self.sprite.current_anim].SPRITE]
        if (buttons['right'], buttons['left']) != (0, 0) and buttons['right'] - buttons['left'] != 0:
            if buttons['left']:
                self.dir = True
            else:
                self.dir = False