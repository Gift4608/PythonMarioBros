import pygame

class Animated_sprite(pygame.sprite.Sprite):
    def __init__(self, animations, pos=(0, 0)):
        super().__init__()
        self.animations = animations
        self.current_anim = 0
        self.image = self.animations[self.current_anim].SPRITES[0]
        self.rect = pygame.rect.Rect(pos, (self.animations[0].SPRITES[0].get_width(), self.animations[0].SPRITES[0].get_height()))
        self.offrect = pygame.rect.Rect((0, 0), (self.animations[0].SPRITES[0].get_width(), self.animations[0].SPRITES[0].get_height()))
    def update_image(self):
        self.image = self.animations[self.current_anim].animation()
    def change_anim(self, id):
        self.animations[self.current_anim].reset()
        self.current_anim = id if id <= len(self.animations) - 1 else 0
    def update(self):
        self.update_image()