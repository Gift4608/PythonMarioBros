import pygame

class Button(pygame.sprite.Sprite):
    def __init__(self, pos, images):
        super().__init__()
        self.pressing = False
        self.old_pressing = False
        self.images = images
        self.rect = self.images[0].get_rect(topleft=(pos))
        self.image = None
        self.update_image()
    def update_image(self):
        self.image = self.images[self.pressing]
    def check_pressing(self, fingers):
        self.old_pressing = self.pressing
        self.pressing = False
        for id, pos in fingers.items():
            if self.rect.collidepoint(pos):
                self.pressing = True
    def update(self, fingers):
        self.check_pressing(fingers)
        self.update_image()